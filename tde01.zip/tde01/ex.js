function sum(a, b) {
    console.log(a + b)
}


function oddOrEven(list) {
    list.forEach(number => {
        if (number % 2 == 0) {
            console.log(`Número ${number} é par`)
            return
        }
        console.log(`Número ${number} é ímpar`)
    });
}

oddOrEven([1, 2, 3, 5, 6, 7])