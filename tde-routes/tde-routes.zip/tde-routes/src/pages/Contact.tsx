import { useState } from 'react';
import NavBar from '../components/navbar';
import { toast } from 'sonner';

interface Contact {
	name: string;
	email: string;
}

const Contact: React.FC = () => {
	const [contacts, setContacts] = useState<Contact[]>([]);
	const [name, setName] = useState('');
	const [email, setEmail] = useState('');

	const handleAddContact = (e: React.FormEvent) => {
		e.preventDefault();

		if (!name || !email) {
			toast.error('Por favor, preencha todos os campos.');
			return;
		}

		const newContact: Contact = { name, email };
		setContacts([...contacts, newContact]);

		setName('');
		setEmail('');
	};

	return (
		<div className="flex h-screen w-screen items-center justify-center font-bold text-2xl">
			<NavBar home={false} about={false} contact={true}></NavBar>
			<div className="flex flex-col h-screen w-screen items-center justify-center font-bold text-2xl">
				<h1 className="text-3xl font-bold mb-6 text-gray-800">
					Página de Contato
				</h1>
				<form
					onSubmit={handleAddContact}
					className="w-full max-w-md bg-white p-6 rounded-lg shadow-md"
				>
					<div className="mb-4">
						<label
							htmlFor="name"
							className="block text-gray-700 font-medium mb-2"
						>
							Nome
						</label>
						<input
							type="text"
							id="name"
							value={name}
							onChange={(e) => setName(e.target.value)}
							className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-400"
							placeholder="Nome"
						/>
					</div>
					<div className="mb-6">
						<label
							htmlFor="email"
							className="block text-gray-700 font-medium mb-2"
						>
							Email
						</label>
						<input
							type="email"
							id="email"
							value={email}
							onChange={(e) => setEmail(e.target.value)}
							className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-400"
							placeholder="Email"
						/>
					</div>
					<button
						type="submit"
						className="w-full bg-blue-400 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition-colors"
					>
						Adicionar Contato
					</button>
				</form>
				<div className="mt-8 w-full max-w-md">
					<h2 className="text-2xl font-semibold text-gray-800 mb-4">
						Lista de Contatos
					</h2>
					<ul className="space-y-3">
						{contacts.map((contact, index) => (
							<li
								key={index}
								className="bg-white p-4 rounded-md shadow-md flex justify-between items-center"
							>
								<span className="text-gray-700 truncate">
									{contact.name}
									<br />
								</span>
								<span className="text-gray-500 truncate">
									{contact.email}
								</span>
							</li>
						))}
					</ul>
				</div>
			</div>
		</div>
	);
};

export { Contact };
