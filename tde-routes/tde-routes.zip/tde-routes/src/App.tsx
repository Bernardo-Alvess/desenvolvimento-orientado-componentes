import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Contact } from './pages/Contact';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Toaster } from 'sonner';

const router = createBrowserRouter([
	{
		path: '/',
		element: <Home />,
	},
	{
		path: '/contact',
		element: <Contact />,
	},
	{
		path: '/about',
		element: <About />,
	},
]);

function App() {
	return (
		<>
			<Toaster richColors></Toaster>
			<RouterProvider router={router} />
		</>
	);
}

export default App;
