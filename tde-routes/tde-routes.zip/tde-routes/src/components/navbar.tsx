import { Link } from 'react-router-dom';

interface Props {
	home: boolean;
	about: boolean;
	contact: boolean;
}

const NavBar = (props: Props) => {
	const { home, about, contact } = props;

	return (
		<div className="h-full min-w-fit flex items-center justify-start px-4 bg-blue-200">
			<nav>
				<li className="flex flex-col gap-10">
					<ul
						className={`hover:text-purple-900 transition-colors ${
							home ? 'text-purple-900' : ''
						}`}
					>
						<Link to={'/'}>- home</Link>
					</ul>
					<ul
						className={`hover:text-green-900 transition-colors ${
							about ? 'text-green-900' : ''
						}`}
					>
						<Link to={'/about'}>- about</Link>
					</ul>
					<ul
						className={`hover:text-blue-900 transition-colors ${
							contact ? 'text-blue-900' : ''
						}`}
					>
						<Link to={'/contact'}>- contact</Link>
					</ul>
				</li>
			</nav>
		</div>
	);
};

export default NavBar;
